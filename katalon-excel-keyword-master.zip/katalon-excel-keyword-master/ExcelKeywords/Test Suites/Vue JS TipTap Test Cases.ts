<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Vue JS TipTap Test Cases</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <testSuiteGuid>7b328df8-bceb-40c5-9c86-edd985bc29e3</testSuiteGuid>
   <testCaseLink>
      <guid>93fefa13-b555-47e5-9883-32f5335cab00</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/VerifyTipTapEditorFunctions</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
