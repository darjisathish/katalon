<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Vue JS Modal Test Cases</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <testSuiteGuid>30adb8e9-ec6f-4c20-8cfb-e4bac0d2ce6c</testSuiteGuid>
   <testCaseLink>
      <guid>d0f7084c-223d-4581-996c-c59a3ae107ed</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/VerifyDefaultVueJSModalText</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>8ee17b20-f56c-48d8-8095-eba93b9f61af</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/VerifyDefaulVueJSModalByKeyword</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
