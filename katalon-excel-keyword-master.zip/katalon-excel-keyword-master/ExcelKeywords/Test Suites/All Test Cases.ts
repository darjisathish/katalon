<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>All Test Cases</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <testSuiteGuid>f9fbc537-78c2-40ed-aeae-dcf567db202b</testSuiteGuid>
   <testCaseLink>
      <guid>4d573128-d481-4502-b7eb-803ec768e987</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/HelloWorldFromWebUiTestCase</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
