<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>iframeResult</name>
   <tag></tag>
   <elementGuidId>b67031ee-0f18-411d-941c-0f57f73177ff</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//iframe[contains(@src, '//fiddle.jshell.net/yyx990803/mwLbw11k/show/light/')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>iframe</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>contains</matchCondition>
      <name>src</name>
      <type>Main</type>
      <value>//fiddle.jshell.net/yyx990803/mwLbw11k/show/light/</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>ref_element</name>
      <type>Main</type>
      <value>Object Repository/vuejs/modal/iframeExamples</value>
   </webElementProperties>
</WebElementEntity>
